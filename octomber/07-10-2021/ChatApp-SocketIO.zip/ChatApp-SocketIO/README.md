# realtime-chat-app
Realtime chat app using socket.io and vanilla JavaScript

#### Demo: https://realtime-gyan-chat-app.herokuapp.com/

## Installation 
After download or clone run `npm install` to install all the dependancies.

🙏 If you find this repo helpful then don't forget to give a start ❇️ to this repository. :)
